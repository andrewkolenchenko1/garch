function [subvector] =  createsample(vector, n) 
subvector = zeros(n,1);
for k = 1 : n
   subvector(k, 1) = vector(k,1); 
end
end