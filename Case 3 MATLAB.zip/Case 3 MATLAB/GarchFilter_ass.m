function [ sigmasquared ] = GarchFilter_ass(parameter_vector,returns)
% Extract the sample size (make sure returns are a column vector)
n     = size(returns,1);
% Extract the stuff we need from the input arguments
mu    = parameter_vector(1,1);
omega = parameter_vector(2,1);
alpha_1 = parameter_vector(3,1);
alpha_2 = parameter_vector(4,1);
beta  = parameter_vector(5,1);
n     = size(returns,1);
% Run the GARCH filter
for t=1:n
    if t==1
        % Initialise at the unconditional mean of sigmasquared
        alpha = (alpha_1 + alpha_2)/2;
        sigmasquared(t,1) = omega/(1-alpha-beta) ;      
    else
        if (returns(t-1,1) - mu)/sqrt(sigmasquared(t-1,1)) < 0
        sigmasquared(t,1) = omega + alpha_1 * (returns(t-1,1)-mu)^2 + beta * sigmasquared(t-1,1);
        else 
        sigmasquared(t,1) = omega + alpha_2 * (returns(t-1,1)-mu)^2 + beta * sigmasquared(t-1,1);
        end
    end
    end
% Close the function
end
