%% Clear all data 
clear
close all

%% Load the directory (change this to where you have saved this file)
pad = '/Users/Rutger-Jan/Dropbox';
cd(pad);
load('data')

%% Get dates in correct Matlab format
dates  = num2str(dates);
dates  = datenum(dates,'yyyymmdd');

%% Plot log returns with dates displayed horizontally
figure
plot(dates,returns,'k')
ylabel('$r_t$','Interpreter','latex')
set(gca, 'XTick', datenum(['20000101';'20010101';'20020101';'20030101';'20040101';'20050101';'20060101';'20070101';'20080101';'20090101';'20100101';'20110101';'20120101';'20130101';'20140101';'20150101';'20160101';'20170101';'20180101';'20190101';'20200101';'20210101';'20220101';'20230101'],'yyyymmdd') )
dateFormat = 'yy';
datetick('x', dateFormat,'keepticks')
xtickangle(0)
set(gca,'FontName','Times','fontsize',20)
set(gca,'TickDir','out')

%% Plot the VIX with dates displayed horizontally
figure
plot(dates,vix,'k')
ylabel('$\mbox{VIX}_t$','Interpreter','latex')
set(gca, 'XTick', datenum(['20000101';'20010101';'20020101';'20030101';'20040101';'20050101';'20060101';'20070101';'20080101';'20090101';'20100101';'20110101';'20120101';'20130101';'20140101';'20150101';'20160101';'20170101';'20180101';'20190101';'20200101';'20210101';'20220101';'20230101'],'yyyymmdd') )
dateFormat = 'yy';
datetick('x', dateFormat,'keepticks')
xtickangle(0)
set(gca,'FontName','Times','fontsize',20)
set(gca,'TickDir','out')

%% Show the negative relationship between differences in the VIX and returns
figure
scatter(diff(vix),returns(2:end),'ok')
set(gca,'FontName','Times','fontsize',20)
set(gca,'TickDir','out')
xlabel('$\Delta \mbox{VIX}_t$','Interpreter','latex')
ylabel('$r_t$','Interpreter','latex')

%% Plot recent returns
figure
plot(dates,returns,'k')
axis([datenum('20200101','yyyymmdd') datenum('20220101','yyyymmdd') -inf inf]) % use `axis' to define axis range
ylabel('$r_t$','Interpreter','latex')
set(gca, 'XTick', datenum(['20200101';'20200701';'20210101';'20210701';'20220101';'20220701';'20230101'],'yyyymmdd') )
dateFormat = 'dd/mm/yy';
datetick('x', dateFormat,'keepticks')
xtickangle(0)
set(gca,'FontName','Times','fontsize',15)
set(gca,'TickDir','out')

%% Specify starting values for the paramsters mu, omega, alpha, beta

format short
startingvalues=[mean(returns);var(returns)/20;0.10;0.85]

%% GARCH: Check the negative log likelihood at the starting values
format bank
ans1=NegativeLogLikelihood(startingvalues,returns)

%% Do maximum likelihood optimsiation 
% Matlab likes to minimize, so we minimise the *negative* log likelihood

% Clear any pre-existing options
clearvars options

% Load some options
options  =  optimset('fmincon');
options  =  optimset(options , 'TolFun'      , 1e-6);
options  =  optimset(options , 'TolX'        , 1e-6);
options  =  optimset(options , 'Display'     , 'on');
options  =  optimset(options , 'Diagnostics' , 'on');
options  =  optimset(options , 'LargeScale'  , 'off');
options  =  optimset(options , 'MaxFunEvals' , 10^6) ;
options  =  optimset(options , 'MaxIter'     , 10^6) ;

% Parameter lower bound and upper bound (note that all parameters except mu must be positive)
lowerbound = [-inf,0,0,0];
upperbound = [inf,inf,inf,inf];

% Perform ML maximisation (we actually minimize the negative likelihood)
format short
[ML_parameters,ML_NegativeLogL]=fmincon('NegativeLogLikelihood', startingvalues ,[],[],[],[],lowerbound,upperbound,[],options,returns )

%% Plot the filtered volatlity path

[ sigmasquared ] = GarchFilter(ML_parameters,returns);

figure
plot(dates,returns)
hold on
plot(dates,sqrt(sigmasquared),'r')
ylabel('$r_t$','Interpreter','latex')
set(gca, 'XTick', datenum(['20000101';'20010101';'20020101';'20030101';'20040101';'20050101';'20060101';'20070101';'20080101';'20090101';'20100101';'20110101';'20120101';'20130101';'20140101';'20150101';'20160101';'20170101';'20180101';'20190101';'20200101';'20210101';'20220101';'20230101'],'yyyymmdd') )
dateFormat = 'yy';
datetick('x', dateFormat,'keepticks')
xtickangle(0)
set(gca,'FontName','Times','fontsize',15)
set(gca,'TickDir','out')

%% Check that the implied shocks have approximately the desired characteristics (mean zero, variance one)
mu_ML = ML_parameters(1);
implied_epsilon=(returns-mu_ML)./sqrt(sigmasquared);
[mean(implied_epsilon);var(implied_epsilon)] % should be roughly [0;1] if the model is correct

