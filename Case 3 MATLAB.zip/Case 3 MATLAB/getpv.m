function [ pv ] = getpv(str, k, d, ML_parameters, sigmasquared)
if strcmp(str, "AGARCH") 
fmu = ML_parameters(1);
fomega = ML_parameters(2);
falpha1 = ML_parameters(3);
falpha2 = ML_parameters(4);
falpha = (falpha1 + falpha2)/2; 
fbeta = ML_parameters(5);
initialsigma_sq1 = (fomega)/(1-falpha-fbeta);
pv = d*(fmu^2 + initialsigma_sq1) + ((1-(falpha+fbeta)^d)/(1-falpha-fbeta)) * (sigmasquared(k, 1)-initialsigma_sq1) ;
else  
    if strcmp(str, "ARGARCH")
        fmu = ML_parameters(1);
        fomega = ML_parameters(2);
        falpha = ML_parameters(3);
        fbeta = ML_parameters(4);
        fgamma = ML_parameters(5);
        fxhi = ML_parameters(6);
        fphi = ML_parameters(7);
        ftau1 = ML_parameters(8);
        ftau2 = ML_parameters(9);
        fsigmau = ML_parameters(10);
        initialsigma_sq2 = (fomega + fgamma*fxhi)/(1-falpha-fbeta-fgamma*fphi);
        fraction1 = (1-(falpha+fbeta+fgamma*fphi)^d)/(1-falpha-fbeta-fgamma*fphi);
        pv = d*(fmu^2 + initialsigma_sq2) + fraction1 * (sigmasquared(k,1) - initialsigma_sq2);
       
    end
end
end