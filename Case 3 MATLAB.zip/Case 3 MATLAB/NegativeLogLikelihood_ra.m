function [negativeLL]=NegativeLogLikelihood_ra(parameter_vector, returns, rv)
%% For Realised Symmetric (rs) GARCH
%% Extract the stuff we need from the input arguments
mu    = parameter_vector(1,1);
omega = parameter_vector(2,1);
alpha = parameter_vector(3,1);
beta  = parameter_vector(4,1);
gamma = parameter_vector(5,1);
xi    = parameter_vector(6,1);
phi   = parameter_vector(7,1);
tau_1 = parameter_vector(8,1);
tau_2 = parameter_vector(9,1);
sigma_u = parameter_vector(10,1);
n       = size(returns,1);


%% Run the GARCH filter
[ sigmasquared ] = GarchFilter_ra(parameter_vector,returns, rv);

% Collect a row vector of log likelihood per observation (this is the log
% of the pdf of a normal distribution)
epsilon = (returns-mu)./sqrt(sigmasquared); 
%fitlm([sigmasquared_srgarch_partial fepsilon], rv5_ss)
LL = - log(2*pi) - 1/2 * log(sigmasquared) - (returns-mu).^2 ./ (2*sigmasquared) - log(sigma_u) - (rv - xi - phi*sigmasquared - tau_1 * epsilon - tau_2 * (epsilon.^2 - 1)).^2 / (2*(sigma_u)^2);

% Put a negative sign in front and sum over all obserations
negativeLL = - sum( LL(1:end) )    ;            

% Close the function
end