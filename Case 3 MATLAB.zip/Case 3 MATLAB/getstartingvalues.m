function [ startingvalues ] = getstartingvalues(str, sample, returns_sample, rv5_ss_sample)
if strcmp(str, "AGARCH")
startingvaluesf = [mean(returns_sample); var(returns_sample)/20; 0.10; 0.10; 0.85];
end
if strcmp(str, "ARGARCH")
        startingvalues1=[mean(returns_sample); var(returns_sample)/20; 0.10; 0.85; 1];
        % Clear any pre-existing options
        clearvars options
        % Load some options
        options  =  optimset('fmincon');
        options  =  optimset(options , 'TolFun'      , 1e-6);
        options  =  optimset(options , 'TolX'        , 1e-6);
        options  =  optimset(options , 'Display'     , 'on');
        options  =  optimset(options , 'Diagnostics' , 'on');
        options  =  optimset(options , 'LargeScale'  , 'off');
        options  =  optimset(options , 'MaxFunEvals' , 10^6) ;
        options  =  optimset(options , 'MaxIter'     , 10^6) ;

        % Parameter lower bound and upper bound (note that all parameters except mu must be positive)
        lowerbound1 = [-inf,0,0,0,0];
        upperbound1 = [inf,inf,inf,inf,inf];
        [ML_parameters_partial,ML_NegativeLogL_partial]=fmincon('NegativeLogLikelihood_rs_partial', startingvalues1,[],[],[],[],lowerbound1,upperbound1,[],options,returns_sample, rv5_ss_sample);
        
        sigmasquared1 = GarchFilter_rs_partial(ML_parameters_partial, returns_sample, rv5_ss_sample);
        
        implied_epsilon1=(returns_sample-ML_parameters_partial(1))./sqrt(sigmasquared1);
        fimplied_epsilon1 = implied_epsilon1.^2 - ones(sample, 1);
        lm = fitlm([sigmasquared1, implied_epsilon1, fimplied_epsilon1], rv5_ss_sample);
        xhi = lm.Coefficients.Estimate(1);
        phi = lm.Coefficients.Estimate(2);
        tau_1 = lm.Coefficients.Estimate(3);
        tau_2 = lm.Coefficients.Estimate(4);
        sigma_u = 1.617; 
        startingvaluesf=[mean(returns_sample); var(returns_sample)/20; 0.01; 0.10; 1; xhi; phi; tau_1; tau_2; sigma_u];    
end
    startingvalues = startingvaluesf;
end