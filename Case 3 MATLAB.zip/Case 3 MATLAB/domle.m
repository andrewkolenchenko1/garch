function [ ML_parameters ] = domle(str, startingvalues, returns_sample, rv5_ss_sample)

% Clear any pre-existing options
clearvars options

% Load some options
options  =  optimset('fmincon');
options  =  optimset(options , 'TolFun'      , 1e-6);
options  =  optimset(options , 'TolX'        , 1e-6);
options  =  optimset(options , 'Display'     , 'on');
options  =  optimset(options , 'Diagnostics' , 'on');
options  =  optimset(options , 'LargeScale'  , 'off');
options  =  optimset(options , 'MaxFunEvals' , 10^6) ;
options  =  optimset(options , 'MaxIter'     , 10^6) ;

% Parameter lower bound and upper bound (note that all parameters except mu must be positive)

if strcmp(str, "AGARCH") 
lowerbound = [-inf,0,0,0,0];
upperbound = [inf,inf,inf,inf,inf];
else 
    if strcmp(str, "ARGARCH") 
     lowerbound = [-inf,0,0,0,0,-inf,-inf,-inf,-inf,-inf]; % positive should be only omega, alpha, beta and gamma
     upperbound = [inf,inf,inf,inf,inf,inf,inf,inf,inf,inf];
    end
end

% Perform ML maximisation (we actually minimize the negative likelihood)
format short
if strcmp(str, "AGARCH") 
[ML_parameters,ML_NegativeLogL] = fmincon('NegativeLogLikelihood_ass', startingvalues ,[],[],[],[],lowerbound,upperbound,[],options,returns_sample );
else
    if strcmp(str, "ARGARCH")
      [ML_parameters,ML_NegativeLogL] = fmincon('NegativeLogLikelihood_ra', startingvalues ,[],[],[],[],lowerbound,upperbound,[],options,returns_sample,rv5_ss_sample );  
    end
end