function [ tvvector ] = gettvvector(tvstr, sample, n, d, dmax, returns, rv5_ss)
        tvvector = zeros(n-sample-dmax, 1);
        if strcmp(tvstr, "TV1") 
        for i = sample+1 : n-dmax
            tv_ind = 0;
            for k = i+1 : i+d
                tv_ind = tv_ind + returns(k, 1).^2;
            end
            tvvector(i-sample, 1) = tv_ind;
        end
        
        else 
         if  strcmp(tvstr, "TV2") 
         for i = sample+1 : n-dmax %This for-loop holds only under the assumption that n-sample is divisible by d 
         tv_ind = 0;
         for k = i+1 : i+d
         tv_ind = tv_ind + 1.4 * rv5_ss(k, 1);
         end
         tvvector(i-sample, 1) = tv_ind;
         end  
         end
         
         
        end
end