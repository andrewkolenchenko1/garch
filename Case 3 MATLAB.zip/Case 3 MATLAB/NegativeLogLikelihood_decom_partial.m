function [negativeLL]= NegativeLogLikelihood_decom_partial(parameter_vector,returns, rv)

% Extract the stuff we need from the input arguments
mu    = parameter_vector(1,1);
omega = parameter_vector(2,1);
alpha_1 = parameter_vector(3,1);
alpha_2 = parameter_vector(4,1);
beta  = parameter_vector(5,1);
gamma_1 = parameter_vector(6,1);
gamma_2 = parameter_vector(7,1);
n     = size(returns,1);

% Run the GARCH filter
[ sigmasquared ] = GarchFilter_decom_partial(parameter_vector,returns, rv);

% Collect a row vector of log likelihood per observation (this is the log
% of the pdf of a normal distribution)
LL = - 1/2 * log(2*pi) - 1/2 * log(sigmasquared) - (returns-mu).^2 ./ (2*sigmasquared) ;

% Put a negative sign in front and sum over all obserations
negativeLL = - sum( LL(1:end) )    ;            

% Close the function
end